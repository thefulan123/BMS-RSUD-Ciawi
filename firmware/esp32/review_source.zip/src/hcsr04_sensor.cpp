#include "hcsr04_sensor.h"

// Constructor: simpan nomor pin.
HcSr04Sensor::HcSr04Sensor(int trigPin, int echoPin)
    : _trigPin(trigPin),
      _echoPin(echoPin)
{
}

// Cara pakai: panggil sekali di setup().
bool HcSr04Sensor::begin()
{
    pinMode(_trigPin, OUTPUT);
    pinMode(_echoPin, INPUT);
    digitalWrite(_trigPin, LOW);
    return true;
}

// Cara pakai: panggil untuk membaca jarak. Kembalikan -1 bila timeout.
float HcSr04Sensor::readCM()
{
    digitalWrite(_trigPin, LOW);
    delayMicroseconds(2);

    digitalWrite(_trigPin, HIGH);
    delayMicroseconds(10);

    digitalWrite(_trigPin, LOW);

    long duration = pulseIn(_echoPin, HIGH, 30000);

    if (duration == 0)
    {
        return -1;  // Tidak ada pantulan -> timeout
    }

    return duration * 0.0343 / 2.0;
}
