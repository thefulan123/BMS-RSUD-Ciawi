#include "wifi_connector.h"

// Constructor: simpan referensi settings agar bisa dipakai di fungsi lain.
WiFiManagerConnector::WiFiManagerConnector(const WifiSettings &settings)
    : _settings(settings)
{
}

// Cara pakai: panggil sekali di setup().
// Fungsi ini akan mencoba connect ke WiFi tersimpan, atau membuat
// Access Point "ESP32-BMS-SETUP" kalau belum ada settingan.
bool WiFiManagerConnector::connect()
{
    Serial.println();
    Serial.println("==============================");
    Serial.println("WiFi Setup");
    Serial.println("==============================");

    WiFiManager wm;

    if (!wm.autoConnect(_settings.accessPointName))
    {
        Serial.println("WiFi connection failed.");
        return false;
    }

    Serial.println();
    Serial.println("WiFi CONNECTED");
    Serial.print("SSID: ");
    Serial.println(WiFi.SSID());
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());

    return true;
}

// Cara pakai: panggil kapan saja untuk mengecek apakah WiFi masih nyambung.
bool WiFiManagerConnector::isConnected()
{
    return WiFi.status() == WL_CONNECTED;
}

// Cara pakai: panggil di loop() bila isConnected() bernilai false,
// supaya ESP32 otomatis mencoba menyambung ke WiFi tersimpan lagi.
bool WiFiManagerConnector::reconnect()
{
    return WiFi.reconnect();
}
